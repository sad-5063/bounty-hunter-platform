import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();

  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async (user) => {
    if (!user) {
      setProfile(null);
      return null;
    }
    try {
      // Use a retry mechanism to handle potential replication delay
      for (let i = 0; i < 3; i++) {
        const { data, error, status } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
        
        if (data) {
            setProfile(data);
            return data;
        }

        if (error && status !== 406) {
          console.warn(`Attempt ${i + 1} to fetch profile failed, retrying...`, error.message);
          await new Promise(res => setTimeout(res, 500 * (i + 1))); // wait 500ms, 1000ms, 1500ms
        } else if (status === 406 && !data) { // No profile found, retrying
            console.warn(`Attempt ${i + 1}: Profile not found yet, retrying...`);
            await new Promise(res => setTimeout(res, 500 * (i + 1)));
        }
      }
      
      console.error('Error fetching profile after retries');
       toast({
          variant: "destructive",
          title: "获取个人资料失败",
          description: "无法从服务器加载您的个人信息，请稍后重试。",
        });
      setProfile(null); // Explicitly set profile to null on final failure
      return null;

    } catch (error) {
      console.error("Critical error fetching profile: ", error);
      toast({
        variant: "destructive",
        title: "严重错误",
        description: "无法加载用户数据，请联系支持。",
      });
      return null;
    }
  }, [toast]);

  const handleAuthStateChange = useCallback(async (event, session) => {
    setLoading(true);
    setSession(session);
    const currentUser = session?.user || null;
    setUser(currentUser);
    
    if (currentUser) {
      await fetchProfile(currentUser);
    } else {
      setProfile(null);
    }
    setLoading(false);
  }, [fetchProfile]);


  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(handleAuthStateChange);
    
    const initialize = async () => {
        const { data: { session } } = await supabase.auth.getSession();
        await handleAuthStateChange('INITIALIZED', session);
    };
    initialize();

    return () => {
      subscription.unsubscribe();
    };
  }, [handleAuthStateChange]);

  const signUp = useCallback(async (email, password, userData) => {
    const isEmailConfirmationDisabled = import.meta.env.VITE_EMAIL_CONFIRMATION_DISABLED === 'true';
    
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username: userData.username,
          avatar_url: userData.avatar_url,
        },
        emailRedirectTo: `${window.location.origin}/login`,
      },
    });

    return { data, error, isEmailConfirmationDisabled };
  }, []);

  const signIn = useCallback(async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { data, error };
  }, []);
  
  const resendConfirmationEmail = useCallback(async (email) => {
    const { data, error } = await supabase.auth.resend({
      type: 'signup',
      email: email,
      options: {
        emailRedirectTo: `${window.location.origin}/login`
      }
    });
    return { data, error };
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setSession(null);
  }, []);

  const value = useMemo(() => ({
    user,
    profile,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    resendConfirmationEmail,
    refreshProfile: () => user ? fetchProfile(user) : Promise.resolve(),
  }), [user, profile, session, loading, signUp, signIn, signOut, resendConfirmationEmail, fetchProfile]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};