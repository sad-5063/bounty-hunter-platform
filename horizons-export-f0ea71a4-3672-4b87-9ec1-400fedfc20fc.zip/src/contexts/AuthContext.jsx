import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('bounty_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = (userData) => {
    setUser(userData);
    localStorage.setItem('bounty_user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('bounty_user');
  };

  const register = (userData) => {
    const newUser = {
      ...userData,
      id: Date.now(),
      balance: 0,
      joinDate: new Date().toISOString(),
      isAdmin: userData.email === 'admin@bounty.com'
    };
    
    const users = JSON.parse(localStorage.getItem('bounty_users') || '[]');
    users.push(newUser);
    localStorage.setItem('bounty_users', JSON.stringify(users));
    
    login(newUser);
    return newUser;
  };

  const updateBalance = (amount) => {
    if (user) {
      const updatedUser = { ...user, balance: user.balance + amount };
      setUser(updatedUser);
      localStorage.setItem('bounty_user', JSON.stringify(updatedUser));
      
      const users = JSON.parse(localStorage.getItem('bounty_users') || '[]');
      const userIndex = users.findIndex(u => u.id === user.id);
      if (userIndex !== -1) {
        users[userIndex] = updatedUser;
        localStorage.setItem('bounty_users', JSON.stringify(users));
      }
    }
  };

  const value = {
    user,
    login,
    logout,
    register,
    updateBalance,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};