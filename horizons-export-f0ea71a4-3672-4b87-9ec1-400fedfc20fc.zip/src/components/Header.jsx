import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Check, Search, Menu, X, Wallet, Briefcase, User, LogOut as LogOutIcon, Bell, Shield, Settings } from 'lucide-react';

const Logo = () => (
  <div className="flex items-center gap-2">
    <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center relative soft-shadow">
      <Check className="text-white w-6 h-6" />
      <div className="absolute -right-1 -bottom-1 w-4 h-4 bg-amber-400 rounded-full flex items-center justify-center border-2 border-background">
        <span className="text-white text-[8px] font-bold">$</span>
      </div>
    </div>
    <span className="text-xl font-bold text-foreground hidden sm:inline">赏金工会</span>
  </div>
);

const NavLinks = ({ isMobile, closeMenu }) => {
  const links = [
    { to: "/", text: "首页" },
    { to: "/tasks", text: "任务大厅" },
    { to: "/my-tasks", text: "我的任务" },
    { to: "/wallet", text: "钱包" },
    { to: "/help", text: "帮助中心" },
  ];

  const navLinkClass = ({ isActive }) =>
    `px-3 py-2 rounded-md text-sm font-medium transition-colors ${
      isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
    } ${isMobile ? 'block w-full text-left' : ''}`;

  return (
    <nav className={`flex ${isMobile ? 'flex-col space-y-2' : 'items-center space-x-1'}`}>
      {links.map(link => (
        <NavLink key={link.to} to={link.to} className={navLinkClass} onClick={closeMenu}>
          {link.text}
        </NavLink>
      ))}
    </nav>
  );
};

const Header = () => {
  const navigate = useNavigate();
  const { profile, signOut } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };
  
  const getInitials = (name) => {
    if (!name) return "U";
    return name.charAt(0).toUpperCase();
  };

  return (
    <header className="bg-background/80 backdrop-blur-lg border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <NavLink to="/" className="flex-shrink-0">
              <Logo />
            </NavLink>
            <div className="hidden md:block">
              <NavLinks />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="搜索任务..." className="pl-9 w-40 lg:w-64" />
              </div>
              <Button onClick={() => navigate('/publish')} className="bg-primary hover:bg-primary/90">发布任务</Button>
            </div>

            {profile ? (
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon">
                  <Bell className="h-5 w-5 text-muted-foreground" />
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                      <Avatar>
                        <AvatarImage src={profile.avatar_url} alt={profile.username} />
                        <AvatarFallback>{getInitials(profile.username)}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>
                      <p className="font-semibold">{profile.username}</p>
                      <p className="text-xs text-muted-foreground">信誉: {profile.reputation_score}</p>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate(`/personal`)}>
                      <User className="mr-2 h-4 w-4" />
                      <span>个人主页</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/my-tasks')}>
                      <Briefcase className="mr-2 h-4 w-4" />
                      <span>我的任务</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/wallet')}>
                      <Wallet className="mr-2 h-4 w-4" />
                      <span>我的钱包</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/settings')}>
                      <Settings className="mr-2 h-4 w-4" />
                      <span>账户设置</span>
                    </DropdownMenuItem>
                    {profile.is_admin && (
                      <DropdownMenuItem onClick={() => navigate('/admin')}>
                        <Shield className="mr-2 h-4 w-4" />
                        <span>管理后台</span>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleSignOut}>
                      <LogOutIcon className="mr-2 h-4 w-4" />
                      <span>退出登录</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              <div className="hidden md:flex items-center gap-2">
                <Button variant="ghost" onClick={() => navigate('/login')}>登录</Button>
                <Button onClick={() => navigate('/register')} className="bg-primary hover:bg-primary/90">注册</Button>
              </div>
            )}

            <div className="md:hidden">
              <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="md:hidden bg-background border-t border-border"
        >
          <div className="px-4 pt-2 pb-4 space-y-2">
            <NavLinks isMobile closeMenu={() => setIsMenuOpen(false)} />
            <div className="relative pt-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="搜索任务..." className="pl-9 w-full" />
            </div>
            <div className="pt-2">
              {profile ? (
                <Button onClick={handleSignOut} className="w-full">退出登录</Button>
              ) : (
                <div className="flex gap-2">
                  <Button variant="outline" className="w-full" onClick={() => { navigate('/login'); setIsMenuOpen(false); }}>登录</Button>
                  <Button className="w-full bg-primary hover:bg-primary/90" onClick={() => { navigate('/register'); setIsMenuOpen(false); }}>注册</Button>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </header>
  );
};

export default Header;