import React from 'react';
import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';

const Logo = () => (
  <div className="flex items-center gap-2">
    <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center relative">
      <Check className="text-white w-6 h-6" />
      <div className="absolute -right-1 -bottom-1 w-4 h-4 bg-amber-400 rounded-full flex items-center justify-center border-2 border-background">
        <span className="text-white text-[8px] font-bold">$</span>
      </div>
    </div>
    <span className="text-xl font-bold text-foreground">赏金工会</span>
  </div>
);

const Footer = () => {
  const quickLinks = [
    { to: '/tasks', text: '任务大厅' },
    { to: '/publish', text: '发布任务' },
    { to: '/help', text: '帮助中心' },
  ];

  const legalLinks = [
    { to: '/user-agreement', text: '用户协议' },
    { to: '/privacy-policy', text: '隐私政策' },
  ];

  return (
    <footer className="bg-secondary/50 border-t border-border">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Link to="/"><Logo /></Link>
            <p className="mt-4 text-muted-foreground max-w-md">
              一个为海外留学生、自由职业者和创作者打造的互助型任务平台。
            </p>
          </div>
          <div>
            <p className="font-semibold text-foreground mb-4">快速链接</p>
            <ul className="space-y-2">
              {quickLinks.map(link => (
                <li key={link.to}>
                  <Link to={link.to} className="text-muted-foreground hover:text-primary transition-colors">
                    {link.text}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="font-semibold text-foreground mb-4">法律</p>
            <ul className="space-y-2">
              {legalLinks.map(link => (
                <li key={link.to}>
                  <Link to={link.to} className="text-muted-foreground hover:text-primary transition-colors">
                    {link.text}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-border pt-6 text-center text-muted-foreground text-sm">
          <p>&copy; {new Date().getFullYear()} 赏金工会. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;