import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FaGoogle, FaFacebook, FaInstagram, FaTiktok } from 'react-icons/fa';
import { useToast } from '@/components/ui/use-toast';

const ProfileSettingsPage = () => {
  const { profile } = useAuth();
  const { toast } = useToast();

  const handleUnlink = (provider) => {
     toast({
        title: `🚧 ${provider} 解绑功能暂未实现`,
        description: '此功能正在开发中！🚀',
     });
  }

  const handleLink = (provider) => {
      toast({
        title: `🚧 ${provider} 绑定功能暂未实现`,
        description: '此功能正在开发中！🚀',
      });
  }

  return (
    <>
      <Helmet>
        <title>账户设置 - 赏金工会</title>
        <meta name="description" content="管理您的账户信息和绑定的第三方账户。" />
      </Helmet>
      <div className="container mx-auto p-4 md:p-8">
        <Card className="max-w-2xl mx-auto rounded-2xl soft-shadow">
          <CardHeader>
            <CardTitle className="text-2xl">账户设置</CardTitle>
            <CardDescription>管理您的个人信息和账户绑定。</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">绑定的账户</h3>
              <p className="text-sm text-muted-foreground mb-4">管理您用于登录的第三方账户。</p>
              <div className="space-y-3">
                
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <FaGoogle className="h-6 w-6 text-red-500" />
                    <span>Google</span>
                  </div>
                  {/* Logic to check if Google is linked */}
                  <Button variant="destructive" size="sm" onClick={() => handleUnlink('Google')}>解绑</Button>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <FaFacebook className="h-6 w-6 text-blue-600" />
                    <span>Facebook</span>
                  </div>
                   {/* Logic to check if Facebook is linked */}
                  <Button variant="destructive" size="sm" onClick={() => handleUnlink('Facebook')}>解绑</Button>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <FaInstagram className="h-6 w-6 text-pink-500" />
                    <span>Instagram</span>
                  </div>
                   {/* Logic to check if Instagram is linked */}
                  <Button variant="destructive" size="sm" onClick={() => handleUnlink('Instagram')}>解绑</Button>
                </div>
                
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <FaTiktok className="h-6 w-6" />
                    <span>TikTok</span>
                  </div>
                  {/* Logic to check if TikTok is linked */}
                  <Button variant="outline" size="sm" onClick={() => handleLink('TikTok')}>绑定</Button>
                </div>

              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default ProfileSettingsPage;