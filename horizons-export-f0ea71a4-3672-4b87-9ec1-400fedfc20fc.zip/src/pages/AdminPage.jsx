import React from 'react';
import { Helmet } from 'react-helmet';

const AdminPage = () => {
  return (
    <>
      <Helmet>
        <title>管理后台 - 赏金工会</title>
        <meta name="description" content="管理平台的用户、任务和财务。" />
      </Helmet>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold">管理后台</h1>
        <p>这里将是管理员的管理面板。</p>
      </div>
    </>
  );
};

export default AdminPage;