import React from 'react';
import { Helmet } from 'react-helmet';

export default function HelpPage() {
  return (
    <>
      <Helmet>
        <title>帮助中心 - 赏金工会</title>
        <meta name="description" content="在这里可以查看常见问题与客服支持。" />
      </Helmet>
      <div>
        <h1>帮助中心</h1>
        <p>在这里可以查看常见问题与客服支持。</p>
      </div>
    </>
  );
}