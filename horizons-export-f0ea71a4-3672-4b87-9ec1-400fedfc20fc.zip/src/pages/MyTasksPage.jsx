import React from 'react';
import { Helmet } from 'react-helmet';

export default function MyTasksPage() {
  return (
    <>
      <Helmet>
        <title>我的任务 - 赏金工会</title>
        <meta name="description" content="这里显示您已发布或已接取的任务。" />
      </Helmet>
      <div>
        <h1>我的任务</h1>
        <p>这里显示您已发布或已接取的任务。</p>
      </div>
    </>
  );
}