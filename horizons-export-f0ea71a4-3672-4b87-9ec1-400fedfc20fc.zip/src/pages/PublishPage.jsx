import React from 'react';
import { Helmet } from 'react-helmet';

export default function PublishPage() {
  return (
    <>
      <Helmet>
        <title>发布任务 - 赏金工会</title>
        <meta name="description" content="在这里填写任务标题、描述和赏金金额。" />
      </Helmet>
      <div>
        <h1>发布任务</h1>
        <p>在这里填写任务标题、描述和赏金金额。</p>
      </div>
    </>
  );
}