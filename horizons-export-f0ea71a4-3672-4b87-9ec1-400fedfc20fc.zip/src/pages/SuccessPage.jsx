import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CheckCircle, ArrowRight } from 'lucide-react';
import Layout from '@/components/Layout';

const SuccessPage = () => {
  return (
    <Layout>
      <Helmet>
        <title>支付成功 - 全球华人赏金公会</title>
        <meta name="description" content="您的支付已成功处理。" />
      </Helmet>
      <div className="container mx-auto px-4 py-16 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, type: 'spring' }}
          className="max-w-md mx-auto glass-card p-8 md:p-12 rounded-2xl"
        >
          <CheckCircle className="mx-auto h-20 w-20 text-green-400 mb-6" />
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
            支付成功！
          </h1>
          <p className="text-gray-300 mb-8">
            感谢您的购买。您的订单正在处理中，您很快就会收到确认邮件。
          </p>
          <Button asChild size="lg" className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold">
            <Link to="/store">
              继续购物
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </Layout>
  );
};

export default SuccessPage;