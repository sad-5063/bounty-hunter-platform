import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, DollarSign } from 'lucide-react';
import { PayPalButtons } from '@paypal/react-paypal-js';
import { supabase } from '@/lib/customSupabaseClient';

const TopUpPage = () => {
  const navigate = useNavigate();
  const { profile, updateBalance, refreshProfile } = useAuth();
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const isPayPalReady = import.meta.env.VITE_PAYPAL_CLIENT_ID && import.meta.env.VITE_PAYPAL_CLIENT_ID !== 'YOUR_PAYPAL_CLIENT_ID';

  const handleAmountChange = (e) => {
    const value = e.target.value;
    if (value === '' || (/^\d*\.?\d{0,2}$/.test(value) && parseFloat(value) >= 0.01)) {
        setAmount(value);
    }
  };

  const createOrder = (data, actions) => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        variant: "destructive",
        title: "无效金额",
        description: "请输入有效的充值金额。",
      });
      return Promise.reject(new Error("Invalid amount"));
    }
    return actions.order.create({
      purchase_units: [
        {
          amount: {
            value: amount,
            currency_code: 'CNY',
          },
          description: `赏金工会账户充值`,
        },
      ],
    });
  };

  const onApprove = async (data, actions) => {
    setIsProcessing(true);
    try {
      const details = await actions.order.capture();
      
      const { error: transactionError } = await supabase
        .from('wallets')
        .insert({
          user_id: profile.id,
          amount: parseFloat(amount),
          transaction_type: 'deposit_paypal',
          status: 'completed',
          bounty_id: null,
        });

      if (transactionError) throw transactionError;

      const { error: balanceError } = await updateBalance(parseFloat(amount));

      if (balanceError) throw balanceError;

      toast({
        title: '充值成功',
        description: `¥${amount} 已成功添加到您的钱包。`,
      });

      await refreshProfile();
      navigate('/wallet');

    } catch (error) {
      console.error("PayPal onApprove Error:", error);
      toast({
        variant: "destructive",
        title: "支付处理失败",
        description: `订单ID: ${data.orderID}. ${error.message}`,
      });
    } finally {
      setIsProcessing(false);
      setAmount('');
    }
  };

  const onError = (err) => {
    console.error("PayPal Error:", err);
    toast({
      variant: "destructive",
      title: "PayPal 错误",
      description: "支付过程中发生错误，请稍后重试。",
    });
  };
  
  const onCancel = (data) => {
    console.log("PayPal payment cancelled:", data);
    toast({
        title: "支付已取消",
        description: "您已取消本次充值操作。",
        variant: "default",
    });
  };

  return (
    <>
      <Helmet>
        <title>账户充值 - 赏金工会</title>
        <meta name="description" content="为您的赏金工会钱包充值。" />
      </Helmet>

      <div className="container mx-auto p-4 md:p-8">
        <Button onClick={() => navigate(-1)} variant="ghost" className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回钱包
        </Button>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md mx-auto"
        >
          <Card className="rounded-2xl soft-shadow">
            <CardHeader>
              <CardTitle className="text-3xl font-bold">账户充值</CardTitle>
              <CardDescription>使用 PayPal 安全快速地为您的钱包充值。</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="amount">充值金额 (CNY)</Label>
                <div className="relative">
                   <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                   <Input 
                    id="amount"
                    name="amount"
                    type="number"
                    placeholder="请输入金额"
                    value={amount}
                    onChange={handleAmountChange}
                    className="pl-9"
                    min="1"
                    step="0.01"
                   />
                </div>
              </div>

              {isProcessing && (
                 <div className="flex justify-center items-center py-4">
                  <div className="w-8 h-8 border-4 border-dashed rounded-full animate-spin border-primary"></div>
                  <p className="ml-4 text-muted-foreground">正在处理您的支付，请稍候...</p>
                </div>
              )}
              
              <div style={{ opacity: isProcessing ? 0.5 : 1, pointerEvents: isProcessing ? 'none' : 'auto' }}>
                 {isPayPalReady ? (
                    <PayPalButtons
                        style={{ layout: "vertical", color: "blue", shape: "rect", label: "pay" }}
                        createOrder={createOrder}
                        onApprove={onApprove}
                        onError={onError}
                        onCancel={onCancel}
                        disabled={!amount || parseFloat(amount) <= 0 || isProcessing}
                    />
                 ) : (
                    <div className="text-center p-4 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200 rounded-lg">
                        <p className="font-semibold">PayPal支付未配置</p>
                        <p className="text-sm">请在 `.env` 文件中提供您的PayPal Client ID以启用充值功能。</p>
                    </div>
                 )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </>
  );
};

export default TopUpPage;