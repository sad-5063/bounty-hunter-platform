import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, Send } from 'lucide-react';

const WithdrawPage = () => {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!profile) {
      toast({ title: '请先登录', variant: 'destructive' });
      return;
    }
    
    const withdrawAmount = parseFloat(amount);
    if (!withdrawAmount || withdrawAmount <= 0) {
      toast({ title: '请输入有效的提现金额', variant: 'destructive' });
      return;
    }

    if (withdrawAmount > profile.balance) {
      toast({ title: '余额不足', description: `您当前的余额为 ¥${profile.balance}`, variant: 'destructive' });
      return;
    }
    
    setLoading(true);
    // Placeholder for withdrawal logic
    setTimeout(() => {
      toast({
        title: '🚧 功能正在开发中',
        description: '提现功能需要更复杂的后端处理，将在未来版本中实现。',
      });
      setLoading(false);
    }, 1500);
  };

  const handleAmountChange = (e) => {
    const value = e.target.value;
    if (value === '' || /^\d*\.?\d{0,2}$/.test(value)) {
        setAmount(value);
    }
  };

  return (
    <>
      <Helmet>
        <title>账户提现 - 赏金工会</title>
        <meta name="description" content="从您的赏金工会钱包提现。" />
      </Helmet>

      <div className="container mx-auto p-4 md:p-8">
        <Button onClick={() => navigate('/wallet')} variant="ghost" className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回钱包
        </Button>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md mx-auto"
        >
          <Card className="rounded-2xl soft-shadow">
            <CardHeader>
              <CardTitle className="text-3xl font-bold">申请提现</CardTitle>
              <CardDescription>将您的钱包余额提现至您的账户。</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-secondary rounded-lg">
                <Label>当前可用余额</Label>
                <p className="text-2xl font-bold text-primary">¥{profile ? profile.balance.toFixed(2) : '0.00'}</p>
              </div>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="amount">提现金额 (CNY)</Label>
                  <Input
                    id="amount"
                    name="amount"
                    type="number"
                    placeholder="请输入提现金额"
                    value={amount}
                    onChange={handleAmountChange}
                    min="1"
                    step="0.01"
                    required
                  />
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="account">提现账户</Label>
                    <Input
                        id="account"
                        name="account"
                        type="text"
                        placeholder="PayPal邮箱或其他账户信息"
                        required
                    />
                </div>
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button type="submit" className="w-full text-lg py-6" disabled={loading}>
                    {loading ? '处理中...' : <><Send className="mr-2 h-5 w-5" />确认提现</>}
                  </Button>
                </motion.div>
                 <p className="text-xs text-muted-foreground text-center">
                    提现功能正在开发中，当前为演示界面。
                </p>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </>
  );
};

export default WithdrawPage;