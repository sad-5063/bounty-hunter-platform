import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/contexts/SupabaseAuthContext";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import { Loader2 } from "lucide-react";

export default function RegisterPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { signUp, signIn } = useAuth();
  const { toast } = useToast();

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);

    // 1. Sign up the user
    const { data: signUpData, error: signUpError, isEmailConfirmationDisabled } = await signUp(email, password, { username });

    if (signUpError) {
      setLoading(false);
      toast({
        title: "注册失败",
        description: signUpError.message,
        variant: "destructive",
      });
      console.error("注册失败:", signUpError);
      return;
    }
    
    // The backend trigger `handle_new_user` creates the profile.
    // There can be a slight replication delay between auth.users and public.profiles.
    // The retry logic is now in SupabaseAuthContext. We'll add a minimal delay here.
    await new Promise(resolve => setTimeout(resolve, 500));

    toast({
      title: "注册成功！",
      description: "正在为您自动登录...",
    });

    // 2. If email confirmation is off, sign them in automatically
    if (isEmailConfirmationDisabled) {
      const { error: signInError } = await signIn(email, password);

      if (signInError) {
        setLoading(false);
        toast({
          title: "自动登录失败",
          description: "请尝试手动登录。",
          variant: "destructive",
        });
        navigate("/login");
      } else {
        setLoading(false);
        toast({
          title: "登录成功",
          description: "欢迎加入赏金工会！",
        });
        navigate("/personal"); // Redirect to the unified personal page
      }
    } else {
        // This case handles when email confirmation is required.
        setLoading(false);
        toast({
          title: "验证邮件已发送",
          description: "请检查您的邮箱并点击链接以完成注册。",
        });
        navigate("/login");
    }
  };


  return (
    <>
      <Helmet>
        <title>注册 - 赏金工会</title>
        <meta name="description" content="加入赏金工会，开始您的任务之旅。" />
      </Helmet>
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-8rem)] bg-secondary/30 p-4">
        <Card className="w-full max-w-md rounded-2xl soft-shadow">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">创建您的账户</CardTitle>
            <CardDescription>加入我们，探索无限可能</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">昵称</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="请输入您的昵称"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">邮箱</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">密码</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="至少6位字符"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {loading ? "正在创建并登录..." : "立即注册并开始"}
              </Button>
            </form>
            <p className="mt-4 text-center text-sm text-muted-foreground">
              已有账号？ <Link to="/login" className="font-medium text-primary hover:underline">直接登录</Link>
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}