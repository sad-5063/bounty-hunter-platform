import React from 'react';
import { Helmet } from 'react-helmet';
import { useParams } from 'react-router-dom';

const BountyDetailPage = () => {
  const { id } = useParams();
  return (
    <>
      <Helmet>
        <title>任务详情 - 赏金工会</title>
        <meta name="description" content={`查看任务 ${id} 的详细信息。`} />
      </Helmet>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold">任务详情页: {id}</h1>
        <p>这里将显示任务的详细信息、发布者资料、附件、预算、截止日期以及操作按钮。</p>
        <p>对应的子域名应是 `task.mydomain.com/${id}`</p>
      </div>
    </>
  );
};

export default BountyDetailPage;