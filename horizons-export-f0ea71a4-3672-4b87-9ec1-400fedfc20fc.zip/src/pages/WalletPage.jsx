import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Minus, History } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

export default function WalletPage() {
  const { profile, loading } = useAuth();
  const { toast } = useToast();

  const handleFeatureNotImplemented = () => {
    toast({
      title: "🚧 此功能尚未实现",
      description: "别担心！您可以在下一次提示中请求它！🚀",
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-8rem)]">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-primary"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>我的钱包 - 赏金工会</title>
        <meta name="description" content="查看您的钱包余额，进行充值和提现操作。" />
      </Helmet>
      <div className="container mx-auto p-4 md:p-8">
        <h1 className="text-4xl font-bold tracking-tight text-center mb-8">我的钱包</h1>
        <Card className="max-w-2xl mx-auto p-6 soft-shadow">
          <CardHeader className="p-0 mb-4">
            <CardTitle className="text-xl">可用余额</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="text-5xl font-extrabold text-primary mb-4">
              ¥{profile?.balance ? profile.balance.toFixed(2) : '0.00'}
            </div>
            <CardDescription className="mb-6">这是您可以随时使用的金额。</CardDescription>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild className="flex-1 text-lg py-6">
                <Link to="/wallet/top-up">
                  <Plus className="w-5 h-5 mr-2" /> 充值
                </Link>
              </Button>
              <Button variant="outline" asChild className="flex-1 text-lg py-6">
                <Link to="/wallet/withdraw">
                  <Minus className="w-5 h-5 mr-2" /> 提现
                </Link>
              </Button>
              <Button variant="ghost" onClick={handleFeatureNotImplemented} className="flex-1 text-lg py-6">
                <History className="w-5 h-5 mr-2" /> 交易历史
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}