import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Star, Shield, Settings, ArrowRight, BookOpen, Mic, Plane, Palette, Code } from 'lucide-react';

const PersonalPage = () => {
  const navigate = useNavigate();
  const { profile, loading: authLoading } = useAuth();

  const categories = [
    { icon: BookOpen, name: '学习辅导', path: '/categories' },
    { icon: Mic, name: '翻译', path: '/categories' },
    { icon: Plane, name: '跑腿代购', path: '/categories' },
    { icon: Palette, name: '设计', path: '/categories' },
    { icon: Code, name: '技术支持', path: '/categories' },
  ];

  const stats = [
    { value: '50,000+', label: '任务完成数' },
    { value: '10,000+', label: '活跃用户' },
    { value: '99.8%', label: '好评率' },
  ];

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-8rem)]">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-primary"></div>
      </div>
    );
  }
  
  if (!profile) {
    return (
       <div className="flex flex-col items-center justify-center min-h-[calc(100vh-8rem)] text-center">
        <p className="text-lg text-muted-foreground">正在加载您的个人资料...</p>
        <p className="text-sm text-muted-foreground mt-2">如果长时间未响应，请尝试刷新页面或重新登录。</p>
        <Button onClick={() => navigate('/login')} className="mt-4">前往登录</Button>
      </div>
    );
  }

  const getInitials = (name) => {
    if (!name) return "新";
    const names = name.split(' ');
    return names.length > 1 ? `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase() : name.substring(0, 2).toUpperCase();
  };

  return (
    <>
      <Helmet>
        <title>{profile.username || "个人主页"} - 赏金工会</title>
        <meta name="description" content={`欢迎回来, ${profile.username || "用户"}！这是您的个人中心主页。`} />
      </Helmet>
      
      {/* Profile Header */}
      <section className="bg-secondary/30 py-8">
        <div className="container mx-auto px-4">
          <Card className="max-w-4xl mx-auto p-4 md:p-6 soft-shadow rounded-2xl">
            <div className="flex flex-col md:flex-row items-center gap-6">
               <Avatar className="h-24 w-24 border-4 border-primary shadow-lg">
                <AvatarImage src={profile.avatar_url} alt={profile.username} />
                <AvatarFallback className="text-3xl bg-secondary">{getInitials(profile.username)}</AvatarFallback>
              </Avatar>
              <div className="text-center md:text-left flex-grow">
                <h1 className="text-3xl font-bold">{profile.username || "新用户"}</h1>
                <p className="mt-1 text-muted-foreground">{profile.email}</p>
                <div className="flex items-center justify-center md:justify-start gap-4 mt-3 text-muted-foreground">
                  <div className="flex items-center gap-1.5 p-2 bg-background rounded-full text-sm">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="font-semibold">信誉: {profile.reputation_score || 100}</span>
                  </div>
                  <div className="flex items-center gap-1.5 p-2 bg-background rounded-full text-sm">
                    <Shield className="w-4 h-4 text-green-500" />
                    <span className="font-semibold">等级: {profile.level || 1}</span>
                  </div>
                </div>
              </div>
               <div className="flex flex-col sm:flex-row md:flex-col gap-2 w-full sm:w-auto">
                 <Button onClick={() => navigate('/wallet')} className="w-full">管理钱包 (¥ {profile.balance ? parseFloat(profile.balance).toFixed(2) : '0.00'})</Button>
                 <Button asChild variant="outline" className="w-full">
                    <Link to="/settings">
                      <Settings className="mr-2 h-4 w-4" />
                      编辑资料
                    </Link>
                  </Button>
               </div>
            </div>
          </Card>
        </div>
      </section>

       {/* Hero-like Call to Action */}
       <section className="py-16 md:py-20 bg-background">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
              准备好开始了吗, <span className="gradient-text">{profile.username}</span>?
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              无论是发布一个新任务，还是寻找一个机会，都从这里开始。
            </p>
            <div className="flex justify-center gap-4">
              <Button size="lg" onClick={() => navigate('/publish')} className="bg-primary hover:bg-primary/90">发布一个新任务</Button>
              <Button size="lg" variant="outline" onClick={() => navigate('/tasks')}>去任务大厅看看</Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories Section (from HomePage) */}
      <section className="py-16 bg-secondary/30">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center text-foreground mb-10">热门分类</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {categories.map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                onClick={() => navigate(category.path)}
              >
                <Card className="text-center p-6 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer rounded-2xl soft-shadow">
                  <div className="w-16 h-16 bg-primary/10 text-primary rounded-full mx-auto flex items-center justify-center mb-4">
                    <category.icon className="w-8 h-8" />
                  </div>
                  <p className="font-semibold text-foreground">{category.name}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Latest Bounties Section (from HomePage) */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h3 className="text-3xl font-bold text-foreground">最新任务</h3>
            <Button variant="ghost" onClick={() => navigate('/latest')}>
              查看全部 <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="rounded-2xl soft-shadow overflow-hidden cursor-pointer" onClick={() => navigate(`/task/${i}`)}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg font-semibold">示例任务标题 {i}</CardTitle>
                    <div className="text-lg font-bold text-primary">¥500</div>
                  </div>
                  <div className="text-sm text-muted-foreground pt-2">
                    <span>截止日期: 2025-10-10</span> | <span>地区: 全球</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4 h-12 overflow-hidden">
                    这是一个示例任务描述，展示了任务内容的大致情况...
                  </p>
                  <Button className="w-full bg-primary/90 hover:bg-primary" onClick={(e) => { e.stopPropagation(); navigate('/task/' + i); }}>快速接取</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section (from HomePage) */}
      <section className="py-16 bg-secondary/30">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center text-foreground mb-10">平台信誉</h3>
          <div className="grid md:grid-cols-3 gap-8 text-center">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
              >
                <p className="text-4xl font-bold text-primary mb-2">{stat.value}</p>
                <p className="text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default PersonalPage;