import React from 'react';
import { Helmet } from 'react-helmet';

const UserAgreementPage = () => {
  return (
    <>
      <Helmet>
        <title>用户协议 - 赏金工会</title>
      </Helmet>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold">用户协议</h1>
        <p>这里是用户协议的内容。</p>
      </div>
    </>
  );
};

export default UserAgreementPage;