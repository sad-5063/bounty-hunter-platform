import React from 'react';
import { Helmet } from 'react-helmet';

export default function CategoriesPage() {
  return (
    <>
      <Helmet>
        <title>热门分类 - 赏金工会</title>
        <meta name="description" content="这里展示不同任务分类，例如：设计、翻译、编程等。" />
      </Helmet>
      <div>
        <h1>热门分类</h1>
        <p>这里展示不同任务分类，例如：设计、翻译、编程等。</p>
      </div>
    </>
  );
}