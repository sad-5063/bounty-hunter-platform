import React from 'react';
import { Helmet } from 'react-helmet';
import BountyHallPage from './BountyHallPage';

export default function TasksPage() {
  return (
    <>
      <Helmet>
        <title>任务大厅 - 赏金工会</title>
        <meta name="description" content="浏览所有可用的任务和悬赏。" />
      </Helmet>
      <BountyHallPage />
    </>
  );
}