import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import ProductsList from '@/components/ProductsList';
import Layout from '@/components/Layout';

const StorePage = () => {
  return (
    <Layout>
      <Helmet>
        <title>商店 - 全球华人赏金公会</title>
        <meta name="description" content="浏览我们精选的独家商品和工具。" />
        <meta property="og:title" content="商店 - 全球华人赏金公会" />
        <meta property="og:description" content="浏览我们精选的独家商品和工具。" />
      </Helmet>
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-6xl font-bold mb-4 gradient-text">
              公会商店
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-2xl mx-auto">
              发现独家商品，助您在赏金猎人的道路上更进一步。
            </p>
          </div>
          <ProductsList />
        </motion.div>
      </div>
    </Layout>
  );
};

export default StorePage;