import React from 'react';
import { Helmet } from 'react-helmet';

export default function LatestTasksPage() {
  return (
    <>
      <Helmet>
        <title>最新任务 - 赏金工会</title>
        <meta name="description" content="这里展示刚刚发布的任务。" />
      </Helmet>
      <div>
        <h1>最新任务</h1>
        <p>这里展示刚刚发布的任务。</p>
      </div>
    </>
  );
}