import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, Mic, Plane, Palette, Code, Users, Trophy, Star, ArrowRight } from 'lucide-react';

const HomePage = () => {
  const navigate = useNavigate();

  const categories = [
    { icon: BookOpen, name: '学习辅导', path: '/categories' },
    { icon: Mic, name: '翻译', path: '/categories' },
    { icon: Plane, name: '跑腿代购', path: '/categories' },
    { icon: Palette, name: '设计', path: '/categories' },
    { icon: Code, name: '技术支持', path: '/categories' },
  ];

  const stats = [
    { value: '50,000+', label: '任务完成数' },
    { value: '10,000+', label: '活跃用户' },
    { value: '99.8%', label: '好评率' },
  ];

  return (
    <>
      <Helmet>
        <title>赏金工会 - 把任务交给懂的人</title>
        <meta name="description" content="赏金工会是一个为海外留学生、自由职业者和创作者打造的互助型任务平台。" />
      </Helmet>

      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-background">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-4">
              把任务交给懂的人
              <span className="text-primary"> | </span>
              完成就拿赏金
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              留学生、创作者、自由职人轻松互助的任务平台
            </p>
            <div className="flex justify-center gap-4">
              <Button size="lg" onClick={() => navigate('/publish')} className="bg-primary hover:bg-primary/90">发布任务</Button>
              <Button size="lg" variant="outline" onClick={() => navigate('/tasks')}>去接任务</Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-secondary/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-foreground mb-10">热门分类</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {categories.map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                onClick={() => navigate(category.path)}
              >
                <Card className="text-center p-6 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer rounded-2xl soft-shadow">
                  <div className="w-16 h-16 bg-primary/10 text-primary rounded-full mx-auto flex items-center justify-center mb-4">
                    <category.icon className="w-8 h-8" />
                  </div>
                  <p className="font-semibold text-foreground">{category.name}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Bounties Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold text-foreground">最新任务</h2>
            <Button variant="ghost" onClick={() => navigate('/latest')}>
              查看全部 <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="rounded-2xl soft-shadow overflow-hidden cursor-pointer" onClick={() => navigate(`/task/${i}`)}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg font-semibold">示例任务标题 {i}</CardTitle>
                    <div className="text-lg font-bold text-primary">¥500</div>
                  </div>
                  <div className="text-sm text-muted-foreground pt-2">
                    <span>截止日期: 2025-10-10</span> | <span>地区: 全球</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4 h-12 overflow-hidden">
                    这是一个示例任务描述，展示了任务内容的大致情况...
                  </p>
                  <Button className="w-full bg-primary/90 hover:bg-primary">快速接取</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-secondary/50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
              >
                <p className="text-4xl font-bold text-primary mb-2">{stat.value}</p>
                <p className="text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;