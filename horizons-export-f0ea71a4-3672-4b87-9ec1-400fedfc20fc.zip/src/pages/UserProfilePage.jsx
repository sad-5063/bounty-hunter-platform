import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Settings, Star, Shield } from 'lucide-react';

const UserProfilePage = () => {
  const { id: routeId } = useParams();
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const profileId = routeId || currentUser?.id;
  
  useEffect(() => {
    const fetchProfile = async () => {
      if (!profileId) {
        navigate('/login');
        return;
      }
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', profileId)
        .single();
      
      if (error) {
        console.error('Error fetching profile:', error);
        navigate('/');
      } else {
        setProfile(data);
      }
      setLoading(false);
    };

    fetchProfile();
  }, [profileId, navigate]);
  
  if (loading) {
    return (
      <div className="container mx-auto p-4 flex justify-center items-center h-[calc(100vh-8rem)]">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-primary"></div>
      </div>
    );
  }

  if (!profile) {
    return <div className="container mx-auto p-4">用户不存在</div>;
  }

  const isOwnProfile = currentUser && currentUser.id === profile.id;

  return (
    <>
      <Helmet>
        <title>{profile.username || '用户'}的主页 - 赏金工会</title>
        <meta name="description" content={`查看 ${profile.username || '用户'} 的主页。`} />
      </Helmet>
      <div className="container mx-auto p-4 md:p-8">
        <Card className="rounded-2xl soft-shadow">
          <CardHeader className="flex flex-col md:flex-row items-center gap-6 p-6">
            <Avatar className="h-24 w-24 border-4 border-primary">
              <AvatarImage src={profile.avatar_url || `https://api.dicebear.com/7.x/micah/svg?seed=${profile.email}`} alt={profile.username} />
              <AvatarFallback className="text-3xl">{profile.username ? profile.username.charAt(0).toUpperCase() : 'U'}</AvatarFallback>
            </Avatar>
            <div className="text-center md:text-left">
              <CardTitle className="text-3xl font-bold">{profile.username}</CardTitle>
              <div className="flex items-center justify-center md:justify-start gap-4 mt-2 text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500" />
                  <span>信誉: {profile.reputation_score || 100}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Shield className="w-4 h-4 text-green-500" />
                  <span>等级: {profile.level || 1}</span>
                </div>
              </div>
            </div>
            {isOwnProfile && (
              <Button variant="outline" size="icon" className="md:ml-auto" onClick={() => navigate('/settings')}>
                <Settings className="h-5 w-5" />
              </Button>
            )}
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-4">发布的任务</h3>
                <p className="text-muted-foreground">功能开发中...</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4">完成的任务</h3>
                <p className="text-muted-foreground">功能开发中...</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default UserProfilePage;