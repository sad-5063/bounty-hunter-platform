import React from 'react';
import { Helmet } from 'react-helmet';

const HelpCenterPage = () => {
  return (
    <>
      <Helmet>
        <title>帮助中心 - 赏金工会</title>
        <meta name="description" content="查找常见问题的答案。" />
      </Helmet>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold">帮助中心</h1>
        <p>这里将包含常见问题、操作指南和联系我们的表单。</p>
      </div>
    </>
  );
};

export default HelpCenterPage;