import React from 'react';
import { Helmet } from 'react-helmet';

const PrivacyPolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>隐私政策 - 赏金工会</title>
      </Helmet>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold">隐私政策</h1>
        <p>这里是隐私政策的内容。</p>
      </div>
    </>
  );
};

export default PrivacyPolicyPage;