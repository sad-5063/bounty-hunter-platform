import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';

const NotFoundPage = () => {
  return (
    <>
      <Helmet>
        <title>404 - 页面未找到</title>
        <meta name="description" content="抱歉，您要查找的页面不存在。" />
      </Helmet>
      <div className="container mx-auto p-4 text-center flex flex-col items-center justify-center min-h-[calc(100vh-8rem)]">
        <AlertTriangle className="w-24 h-24 text-primary mb-4" />
        <h1 className="text-4xl font-bold mb-2">404 - 页面未找到</h1>
        <p className="text-muted-foreground mb-6">抱歉，您要查找的页面不存在。</p>
        <Button asChild>
          <Link to="/">返回首页</Link>
        </Button>
      </div>
    </>
  );
};

export default NotFoundPage;