import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/contexts/SupabaseAuthContext";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal, Loader2 } from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const { signIn, resendConfirmationEmail } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [emailNotConfirmed, setEmailNotConfirmed] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setEmailNotConfirmed(false);

    const { data, error } = await signIn(email, password);
    
    setLoading(false);
    
    if (error) {
      console.error("登录失败:", error);
      if (error.message === 'Email not confirmed') {
        setEmailNotConfirmed(true);
      } else {
        toast({
          title: "登录失败",
          description: error.message === 'Invalid login credentials' ? '邮箱或密码不正确' : error.message,
          variant: "destructive",
        });
      }
    } else {
      console.log("登录成功的用户信息:", data.user);
      toast({
        title: "登录成功",
        description: "欢迎回来！",
      });
      navigate(`/personal`);
    }
  };

  const handleResend = async () => {
    setResendLoading(true);
    const { error } = await resendConfirmationEmail(email);
    setResendLoading(false);

    if (error) {
      toast({
        title: "发送失败",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "发送成功",
        description: "已重新发送验证邮件，请检查您的收件箱。",
      });
      setEmailNotConfirmed(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>登录 - 赏金工会</title>
        <meta name="description" content="登录您的赏金工会账户。" />
      </Helmet>
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-8rem)] bg-secondary/30 p-4">
        <Card className="w-full max-w-md rounded-2xl soft-shadow">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">欢迎回来</CardTitle>
            <CardDescription>登录以继续</CardDescription>
          </CardHeader>
          <CardContent>
            {emailNotConfirmed && (
              <Alert variant="destructive" className="mb-4">
                <Terminal className="h-4 w-4" />
                <AlertTitle>邮箱未验证</AlertTitle>
                <AlertDescription className="flex flex-col gap-2">
                  <p>请先检查您的收件箱并点击验证链接。</p>
                  <Button 
                    onClick={handleResend} 
                    disabled={resendLoading}
                    variant="outline"
                    size="sm"
                    className="w-fit"
                  >
                    {resendLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {resendLoading ? "发送中..." : "重新发送验证邮件"}
                  </Button>
                </AlertDescription>
              </Alert>
            )}
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">邮箱</Label>
                <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">密码</Label>
                <Input id="password" type="password" placeholder="请输入密码" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {loading ? "登录中..." : "登录"}
              </Button>
            </form>
            <div className="mt-4 text-center text-sm">
              <p className="text-muted-foreground">
                还没有账号？ <Link to="/register" className="font-medium text-primary hover:underline">去注册</Link>
              </p>
              <p className="mt-2 text-muted-foreground">
                <Link to="/password-reset" className="font-medium text-primary hover:underline">
                  忘记密码？
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}