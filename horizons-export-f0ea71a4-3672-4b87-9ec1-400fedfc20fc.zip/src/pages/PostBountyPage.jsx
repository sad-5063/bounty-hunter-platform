import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, PlusCircle, User, Mail } from 'lucide-react';

const PostBountyPage = () => {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    budget: '',
    category: '',
    deadline: '',
    region: '全球',
    publisher_name: '',
    publisher_email: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const taskData = {
      title: formData.title,
      description: formData.description,
      budget: parseFloat(formData.budget),
      category: formData.category,
      deadline: formData.deadline,
      region: formData.region,
      status: '待接取',
    };

    if (user) {
      taskData.user_id = user.id;
      taskData.publisher_name = profile?.name || '匿名用户';
    } else {
      if (!formData.publisher_name.trim() || !formData.publisher_email.trim()) {
        toast({ title: '信息不完整', description: '请填写您的昵称和联系邮箱。', variant: 'destructive' });
        setLoading(false);
        return;
      }
      taskData.publisher_name = formData.publisher_name;
      taskData.publisher_email = formData.publisher_email;
    }

    const { error } = await supabase.from('tasks').insert(taskData);

    setLoading(false);

    if (error) {
      toast({ title: '发布失败', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: '任务发布成功！', description: '您的任务已成功发布到任务大厅。' });
      navigate('/tasks');
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSelectChange = (name, value) => {
    setFormData({ ...formData, [name]: value });
  };
  
  const categories = [
    { value: 'study', label: '学习辅导' },
    { value: 'translation', label: '翻译' },
    { value: 'errand', label: '跑腿' },
    { value: 'purchase', label: '代购' },
    { value: 'design', label: '设计' },
    { value: 'tech', label: '技术支持' },
    { value: 'other', label: '其他' },
  ];
  
  const locations = [ '全球', '中国', '美国', '加拿大', '澳大利亚', '英国', '新加坡', '日本', '韩国', '其他' ];


  return (
    <>
      <Helmet>
        <title>发布新任务 - 赏金工会</title>
        <meta name="description" content="在赏金工会发布一个新任务，让社区成员来帮助您。" />
      </Helmet>

      <div className="container mx-auto p-4 md:p-8">
        <Button onClick={() => navigate(-1)} variant="ghost" className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl mx-auto"
        >
          <Card className="rounded-2xl soft-shadow">
            <CardHeader>
              <CardTitle className="text-3xl font-bold">发布一个新任务</CardTitle>
              <CardDescription>详细描述您的需求，设定合理的预算，等待能人来接单。</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {!user && (
                    <Card className="bg-primary/5 border-primary/20 p-4">
                        <CardHeader className="p-2">
                            <CardTitle className="text-lg">匿名发布</CardTitle>
                            <CardDescription>您当前未登录。请留下您的联系方式，以便任务接取者与您沟通。</CardDescription>
                        </CardHeader>
                        <CardContent className="p-2 space-y-4">
                             <div className="space-y-2">
                                <Label htmlFor="publisher_name">您的昵称</Label>
                                <div className="relative">
                                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input id="publisher_name" name="publisher_name" required value={formData.publisher_name} onChange={handleChange} placeholder="您希望被如何称呼" className="pl-9" />
                                </div>
                            </div>
                             <div className="space-y-2">
                                <Label htmlFor="publisher_email">联系邮箱</Label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input id="publisher_email" name="publisher_email" type="email" required value={formData.publisher_email} onChange={handleChange} placeholder="用于接收任务通知" className="pl-9" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}

                <div className="space-y-2">
                  <Label htmlFor="title">任务标题</Label>
                  <Input id="title" name="title" required value={formData.title} onChange={handleChange} placeholder="例如：求一份多伦多大学CS课程笔记" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">详细描述</Label>
                  <Textarea id="description" name="description" required value={formData.description} onChange={handleChange} placeholder="请详细说明任务内容、要求和交付标准..." rows={5} />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="budget">预算金额 (CNY)</Label>
                    <Input id="budget" name="budget" type="number" required value={formData.budget} onChange={handleChange} placeholder="例如: 100" min="1" step="0.01" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">任务分类</Label>
                    <Select onValueChange={(value) => handleSelectChange('category', value)} value={formData.category}>
                      <SelectTrigger id="category">
                        <SelectValue placeholder="选择分类" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(cat => <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="deadline">截止日期</Label>
                        <Input id="deadline" name="deadline" type="date" required value={formData.deadline} onChange={handleChange} min={new Date().toISOString().split("T")[0]}/>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="region">任务地区</Label>
                         <Select onValueChange={(value) => handleSelectChange('region', value)} defaultValue="全球">
                          <SelectTrigger id="region">
                            <SelectValue placeholder="选择地区" />
                          </SelectTrigger>
                          <SelectContent>
                            {locations.map(loc => <SelectItem key={loc} value={loc}>{loc}</SelectItem>)}
                          </SelectContent>
                        </Select>
                    </div>
                </div>

                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button type="submit" className="w-full text-lg py-6" disabled={loading}>
                    {loading ? '发布中...' : <><PlusCircle className="mr-2 h-5 w-5" />确认发布</>}
                  </Button>
                </motion.div>
                 <p className="text-xs text-muted-foreground text-center">
                    发布任务即表示您同意我们的<Link to="/user-agreement" className="underline">用户协议</Link>和<Link to="/privacy-policy" className="underline">隐私政策</Link>。
                </p>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </>
  );
};

export default PostBountyPage;