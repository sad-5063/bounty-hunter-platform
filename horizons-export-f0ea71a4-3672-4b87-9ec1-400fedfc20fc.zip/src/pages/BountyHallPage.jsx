import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { MapPin, Tag, ArrowRight, DollarSign, Clock, Search, Briefcase } from 'lucide-react';

const BountyCard = ({ bounty }) => {
  const navigate = useNavigate();
  const daysLeft = bounty.deadline ? Math.ceil((new Date(bounty.deadline) - new Date()) / (1000 * 60 * 60 * 24)) : null;

  const categories = {
    study: '学习辅导',
    translation: '翻译',
    errand: '跑腿',
    purchase: '代购',
    design: '设计',
    tech: '技术支持',
    other: '其他'
  };
  
  const handleCardClick = () => {
      navigate(`/task/${bounty.id}`);
  }

  return (
    <motion.div 
      whileHover={{ y: -5, boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)" }}
      className="bg-card rounded-2xl overflow-hidden soft-shadow h-full flex flex-col"
      onClick={handleCardClick}
      style={{ cursor: 'pointer' }}
    >
      <CardHeader>
        <div className="flex justify-between items-start mb-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Tag className="w-4 h-4 text-primary"/>
                <span>{categories[bounty.category] || '其他'}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4 text-primary"/>
                <span>{bounty.region || '全球'}</span>
            </div>
        </div>
        <CardTitle className="text-lg font-semibold line-clamp-2">{bounty.title}</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col justify-between">
        <div>
            <CardDescription className="line-clamp-3 mb-4">{bounty.description}</CardDescription>
            <div className="flex items-center text-primary font-bold text-xl mb-4">
                <DollarSign className="w-5 h-5 mr-1" />
                {bounty.budget} <span className="text-sm font-normal text-muted-foreground ml-1">CNY</span>
            </div>
        </div>
        <div className="flex justify-between items-center text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
                <Clock className="w-4 h-4"/>
                {daysLeft !== null ? (
                    <span>{daysLeft > 0 ? `还剩 ${daysLeft} 天` : '已截止'}</span>
                ) : <span>无截止日期</span>}
            </div>
            <Button variant="ghost" size="sm" className="h-auto px-2 py-1">
                查看详情 <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
        </div>
      </CardContent>
    </motion.div>
  );
};


const BountyHallPage = () => {
  const { toast } = useToast();
  const [bounties, setBounties] = useState([]);
  const [filteredBounties, setFilteredBounties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    category: 'all',
    region: 'all',
    sortBy: 'created_at-desc',
  });

  const categories = [
    { value: 'all', label: '所有分类' },
    { value: 'study', label: '学习辅导' },
    { value: 'translation', label: '翻译' },
    { value: 'errand', label: '跑腿' },
    { value: 'purchase', label: '代购' },
    { value: 'design', label: '设计' },
    { value: 'tech', label: '技术支持' },
    { value: 'other', label: '其他'}
  ];
  
  const locations = [ '全球', '中国', '美国', '加拿大', '澳大利亚', '英国', '新加坡', '日本', '韩国' ];

  useEffect(() => {
    const fetchBounties = async () => {
      setLoading(true);
      let { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('status', 'open');

      if (error) {
        toast({ title: '获取任务失败', description: error.message, variant: 'destructive' });
      } else {
        setBounties(data);
      }
      setLoading(false);
    };
    fetchBounties();
  }, [toast]);
  
  useEffect(() => {
    let result = bounties;
    
    if(searchTerm) {
        result = result.filter(b => b.title.toLowerCase().includes(searchTerm.toLowerCase()) || b.description.toLowerCase().includes(searchTerm.toLowerCase()));
    }

    if(filters.category !== 'all') {
        result = result.filter(b => b.category === filters.category);
    }
    if(filters.region !== 'all') {
        if (filters.region === '全球') {
             result = result.filter(b => b.region && b.region.toLowerCase() === '全球');
        } else {
             result = result.filter(b => b.region && b.region.toLowerCase().includes(filters.region.toLowerCase()));
        }
    }

    const [field, direction] = filters.sortBy.split('-');
    result.sort((a, b) => {
        let valA = a[field];
        let valB = b[field];

        if (field === 'created_at' || field === 'deadline') {
            valA = new Date(valA);
            valB = new Date(valB);
        }
        
        if (valA < valB) return direction === 'asc' ? -1 : 1;
        if (valA > valB) return direction === 'asc' ? 1 : -1;
        return 0;
    });

    setFilteredBounties(result);
  }, [bounties, searchTerm, filters]);

  const handleFilterChange = (name, value) => {
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  return (
    <>
      <Helmet>
        <title>赏金工会 - 任务大厅</title>
        <meta name="description" content="浏览所有可接取的任务，并根据您的偏好进行筛选。" />
      </Helmet>
      <div className="container mx-auto p-4 md:p-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-tight mb-2">赏金工会</h1>
          <p className="text-lg text-muted-foreground">发现机会，施展才华</p>
        </motion.div>

        <Card className="p-4 mb-8 soft-shadow rounded-2xl">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="搜索任务标题或描述..." 
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select onValueChange={(value) => handleFilterChange('category', value)} defaultValue="all">
              <SelectTrigger><SelectValue placeholder="所有分类" /></SelectTrigger>
              <SelectContent>
                {categories.map(cat => <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select onValueChange={(value) => handleFilterChange('region', value)} defaultValue="all">
              <SelectTrigger><SelectValue placeholder="所有地区" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">所有地区</SelectItem>
                {locations.map(loc => <SelectItem key={loc} value={loc}>{loc}</SelectItem>)}
              </SelectContent>
            </Select>
             <Select onValueChange={(value) => handleFilterChange('sortBy', value)} defaultValue="created_at-desc">
              <SelectTrigger><SelectValue placeholder="排序方式" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="created_at-desc">最新发布</SelectItem>
                <SelectItem value="budget-desc">金额最高</SelectItem>
                <SelectItem value="budget-asc">金额最低</SelectItem>
                <SelectItem value="deadline-asc">即将截止</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>

        {loading ? (
          <div className="text-center py-16">
            <div className="w-12 h-12 border-4 border-dashed rounded-full animate-spin border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">正在加载任务...</p>
          </div>
        ) : filteredBounties.length > 0 ? (
          <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBounties.map(bounty => (
              <BountyCard key={bounty.id} bounty={bounty} />
            ))}
          </motion.div>
        ) : (
          <div className="text-center py-16 rounded-2xl bg-secondary/50">
            <Briefcase className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold">未找到匹配的任务</h3>
            <p className="text-muted-foreground mt-2">尝试调整您的搜索或筛选条件，或稍后再来看看。</p>
          </div>
        )}
      </div>
    </>
  );
};

export default BountyHallPage;