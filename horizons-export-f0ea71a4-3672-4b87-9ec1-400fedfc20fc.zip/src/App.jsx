import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { AnimatePresence } from 'framer-motion';
import Layout from '@/components/Layout';
import { PayPalScriptProvider } from '@paypal/react-paypal-js';

import HomePage from '@/pages/HomePage';
import RegisterPage from '@/pages/RegisterPage';
import LoginPage from '@/pages/LoginPage';
import PostBountyPage from '@/pages/PostBountyPage';
import BountyHallPage from '@/pages/BountyHallPage';
import BountyDetailPage from '@/pages/BountyDetailPage';
import WalletPage from '@/pages/WalletPage';
import MyTasksPage from '@/pages/MyTasksPage';
import HelpCenterPage from '@/pages/HelpCenterPage';
import UserProfilePage from '@/pages/UserProfilePage';
import AdminPage from '@/pages/AdminPage';
import PrivacyPolicyPage from '@/pages/PrivacyPolicyPage';
import UserAgreementPage from '@/pages/UserAgreementPage';
import ProfileSettingsPage from '@/pages/ProfileSettingsPage';
import TopUpPage from '@/pages/TopUpPage';
import WithdrawPage from '@/pages/WithdrawPage';
import NotFoundPage from '@/pages/NotFoundPage';
import CategoriesPage from '@/pages/CategoriesPage';
import LatestTasksPage from '@/pages/LatestTasksPage';
import PersonalPage from '@/pages/PersonalPage';

const PAYPAL_CLIENT_ID = import.meta.env.VITE_PAYPAL_CLIENT_ID || "YOUR_PAYPAL_CLIENT_ID";

function App() {
  const { loading, user } = useAuth();

  const ProtectedRoute = ({ children }) => {
    if (!loading && !user) {
      return <Navigate to="/login" replace />;
    }
    return children;
  };

  return (
    <PayPalScriptProvider options={{ "client-id": PAYPAL_CLIENT_ID, currency: "CNY" }}>
      <Layout>
        <AnimatePresence mode="wait">
          {loading ? (
            <div key="loader" className="fixed inset-0 flex items-center justify-center bg-background z-[100]">
              <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-primary"></div>
            </div>
          ) : (
            <Routes>
              <Route path="/" element={<BountyHallPage />} />
              <Route path="/home" element={<HomePage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/login" element={<LoginPage />} />
              
              <Route path="/tasks" element={<BountyHallPage />} />
              <Route path="/task/:id" element={<BountyDetailPage />} />
              <Route path="/publish" element={<PostBountyPage />} />
              
              <Route path="/my-tasks" element={<ProtectedRoute><MyTasksPage /></ProtectedRoute>} />
              <Route path="/wallet" element={<ProtectedRoute><WalletPage /></ProtectedRoute>} />
              <Route path="/wallet/top-up" element={<ProtectedRoute><TopUpPage /></ProtectedRoute>} />
              <Route path="/wallet/withdraw" element={<ProtectedRoute><WithdrawPage /></ProtectedRoute>} />
              
              <Route path="/help" element={<HelpCenterPage />} />
              <Route path="/personal/:id" element={<UserProfilePage />} />
              <Route path="/personal" element={<ProtectedRoute><PersonalPage /></ProtectedRoute>} />
              <Route path="/settings" element={<ProtectedRoute><ProfileSettingsPage /></ProtectedRoute>} />
              
              <Route path="/admin" element={<AdminPage />} />
              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
              <Route path="/user-agreement" element={<UserAgreementPage />} />
              <Route path="/password-reset" element={<div>Password Reset Page</div>} />

              <Route path="/categories" element={<CategoriesPage />} />
              <Route path="/latest" element={<LatestTasksPage />} />

              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          )}
        </AnimatePresence>
      </Layout>
    </PayPalScriptProvider>
  );
}

const AppWrapper = () => (
  <Router>
    <App />
  </Router>
);

export default AppWrapper;