# 赏金猎人任务平台

一个现代化的任务发布与执行平台，连接任务发布者和执行者。

## 功能特色

- 🎯 **用户系统**: 注册、登录、个人中心
- 📋 **任务系统**: 发布任务、浏览任务、接受任务
- 💰 **钱包系统**: 余额管理、充值提现、交易记录
- ⭐ **评价系统**: 任务完成后互相评价
- 💬 **消息系统**: 站内私信、系统通知
- 🔧 **管理后台**: 用户管理、任务管理、资金管理

## 技术栈

- **前端**: React 18, Vite, React Router DOM
- **样式**: CSS3, 响应式设计
- **状态管理**: React Context API
- **构建工具**: Vite

## 快速开始

### 安装依赖

```bash
npm install
```

### 启动开发服务器

```bash
npm run dev
```

### 构建生产版本

```bash
npm run build
```

### 预览生产版本

```bash
npm run preview
```

## 项目结构

```
src/
├── components/          # 组件
│   ├── Header.jsx      # 页头组件
│   ├── Footer.jsx      # 页脚组件
│   └── ProtectedRoute.jsx # 路由保护组件
├── contexts/           # 上下文
│   └── AuthContext.jsx # 认证上下文
├── pages/              # 页面
│   ├── HomePage.jsx    # 首页
│   ├── LoginPage.jsx   # 登录页
│   ├── RegisterPage.jsx # 注册页
│   ├── DashboardPage.jsx # 个人中心
│   ├── TaskHallPage.jsx # 任务大厅
│   ├── TaskDetailPage.jsx # 任务详情
│   ├── WalletPage.jsx  # 钱包页面
│   ├── MessagesPage.jsx # 消息页面
│   └── AdminPage.jsx   # 管理后台
├── App.jsx             # 主应用组件
├── App.css             # 主应用样式
├── main.jsx            # 入口文件
└── index.css           # 全局样式
```

## 部署

### Vercel 部署

1. 将代码推送到 GitHub
2. 在 Vercel 中导入项目
3. 配置环境变量
4. 部署

### 环境变量

```
NODE_ENV=production
```

## 许可证

MIT License

## 联系方式

- 邮箱: support@bountyhunterguild.com
- 网站: https://bountyhunterguild.com