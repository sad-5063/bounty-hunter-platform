import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './TaskHallPage.css';

const TaskHallPage = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    category: '',
    minReward: '',
    maxReward: ''
  });

  useEffect(() => {
    // 模拟获取任务数据
    const mockTasks = [
      {
        id: 1,
        title: '网站设计任务',
        description: '需要一个现代化的企业官网设计',
        category: '设计',
        reward: 2000,
        deadline: '2025-01-15',
        status: 'open',
        publisher: '张三'
      },
      {
        id: 2,
        title: '内容创作',
        description: '撰写技术博客文章，要求原创',
        category: '写作',
        reward: 500,
        deadline: '2025-01-20',
        status: 'open',
        publisher: '李四'
      },
      {
        id: 3,
        title: '数据分析',
        description: '分析用户行为数据，提供报告',
        category: '数据分析',
        reward: 1500,
        deadline: '2025-01-18',
        status: 'open',
        publisher: '王五'
      }
    ];
    
    setTimeout(() => {
      setTasks(mockTasks);
      setLoading(false);
    }, 1000);
  }, []);

  const handleFilterChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value
    });
  };

  const filteredTasks = tasks.filter(task => {
    if (filters.category && task.category !== filters.category) return false;
    if (filters.minReward && task.reward < parseInt(filters.minReward)) return false;
    if (filters.maxReward && task.reward > parseInt(filters.maxReward)) return false;
    return true;
  });

  if (loading) {
    return (
      <div className="task-hall-page">
        <div className="loading">加载中...</div>
      </div>
    );
  }

  return (
    <div className="task-hall-page">
      <div className="task-hall-container">
        <h1>任务大厅</h1>
        
        <div className="filters">
          <h3>筛选条件</h3>
          <div className="filter-row">
            <select 
              name="category" 
              value={filters.category} 
              onChange={handleFilterChange}
            >
              <option value="">所有分类</option>
              <option value="设计">设计</option>
              <option value="写作">写作</option>
              <option value="数据分析">数据分析</option>
              <option value="编程">编程</option>
            </select>
            
            <input
              type="number"
              name="minReward"
              placeholder="最低赏金"
              value={filters.minReward}
              onChange={handleFilterChange}
            />
            
            <input
              type="number"
              name="maxReward"
              placeholder="最高赏金"
              value={filters.maxReward}
              onChange={handleFilterChange}
            />
          </div>
        </div>
        
        <div className="tasks-grid">
          {filteredTasks.map(task => (
            <div key={task.id} className="task-card">
              <h3>{task.title}</h3>
              <p className="task-description">{task.description}</p>
              <div className="task-meta">
                <span className="category">{task.category}</span>
                <span className="reward">¥{task.reward}</span>
                <span className="deadline">{task.deadline}</span>
              </div>
              <div className="task-actions">
                <Link to={`/tasks/${task.id}`} className="btn btn-primary">
                  查看详情
                </Link>
                <button className="btn btn-secondary">接受任务</button>
              </div>
            </div>
          ))}
        </div>
        
        {filteredTasks.length === 0 && (
          <div className="no-tasks">
            <p>没有找到符合条件的任务</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskHallPage;