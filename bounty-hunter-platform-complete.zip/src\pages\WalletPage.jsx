import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import './WalletPage.css';

const WalletPage = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('balance');
  const [transactions] = useState([
    {
      id: 1,
      type: 'income',
      amount: 2000,
      description: '任务完成收入',
      date: '2025-01-10',
      status: 'completed'
    },
    {
      id: 2,
      type: 'expense',
      amount: 500,
      description: '任务发布费用',
      date: '2025-01-09',
      status: 'completed'
    },
    {
      id: 3,
      type: 'income',
      amount: 1500,
      description: '任务完成收入',
      date: '2025-01-08',
      status: 'completed'
    }
  ]);

  return (
    <div className="wallet-page">
      <div className="wallet-container">
        <h1>我的钱包</h1>
        
        <div className="wallet-overview">
          <div className="balance-card">
            <h3>当前余额</h3>
            <div className="balance-amount">¥{user?.wallet_balance || 0}</div>
            <div className="balance-actions">
              <button className="btn btn-primary">充值</button>
              <button className="btn btn-secondary">提现</button>
            </div>
          </div>
        </div>
        
        <div className="wallet-tabs">
          <button 
            className={`tab ${activeTab === 'balance' ? 'active' : ''}`}
            onClick={() => setActiveTab('balance')}
          >
            余额管理
          </button>
          <button 
            className={`tab ${activeTab === 'transactions' ? 'active' : ''}`}
            onClick={() => setActiveTab('transactions')}
          >
            交易记录
          </button>
        </div>
        
        <div className="wallet-content">
          {activeTab === 'balance' && (
            <div className="balance-section">
              <div className="balance-actions-grid">
                <div className="action-card">
                  <h3>充值</h3>
                  <p>向钱包充值资金</p>
                  <button className="btn btn-primary">立即充值</button>
                </div>
                <div className="action-card">
                  <h3>提现</h3>
                  <p>提取钱包余额</p>
                  <button className="btn btn-secondary">申请提现</button>
                </div>
                <div className="action-card">
                  <h3>绑定银行卡</h3>
                  <p>绑定银行卡便于提现</p>
                  <button className="btn btn-secondary">绑定</button>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'transactions' && (
            <div className="transactions-section">
              <div className="transactions-list">
                {transactions.map(transaction => (
                  <div key={transaction.id} className="transaction-item">
                    <div className="transaction-info">
                      <div className="transaction-type">
                        {transaction.type === 'income' ? '收入' : '支出'}
                      </div>
                      <div className="transaction-description">
                        {transaction.description}
                      </div>
                      <div className="transaction-date">
                        {transaction.date}
                      </div>
                    </div>
                    <div className="transaction-amount">
                      <span className={`amount ${transaction.type}`}>
                        {transaction.type === 'income' ? '+' : '-'}¥{transaction.amount}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WalletPage;